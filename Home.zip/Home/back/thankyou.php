<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Hiroto Template">
    <meta name="keywords" content="Hiroto, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
 <title>Sea Side South Park</title>

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Offcanvas Menu Begin -->
    <div class="offcanvas-menu-overlay"></div>
    
    <!-- Header Section Begin -->
    <header class="header">
       
        <div class="header__nav__option">
            <div class="container">
                <div class="row">
                    <div class="col-lg-2">
                        <div class="header__logo">
                            <a href="./index.html"><img src="img/logo.png" alt=""></a>
                        </div>
                    </div>
                    <div class="col-lg-10">
                        <div class="header__nav">
                            <nav class="header__menu">
                                 <ul class="menu__class">
                                    <li class="active"><a href="./index.html">Home</a></li>
                                    <li><a href="./seasidehotel/index.html">About Us</a></li>
                                    <li><a href="about.html">Other Hotels</a></li>
                                    <li><a href="#">Pages</a>
                                        <ul class="dropdown">
                                            <li><a href="./seasidehotel/index.html">About Us</a></li>
                                            <li><a href="./about.html">Other Hotels</a></li>
                                            <li><a href="./register.html">Register</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="./register.html">Register</a></li>
                                    <li><a href="./contact.html">Contact</a></li>
                                </ul>
                            </nav>
                            <div class="header__nav__widget">
                                <a href="#">Book Now <span class="arrow_right"></span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="canvas__open">
                    <span class="fa fa-bars"></span>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Section End -->

    <!-- Breadcrumb Begin -->
    <div class="breadcrumb-option set-bg" data-setbg="img/jj.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h1>Our Multiple Hotels</h1>
                        <div class="breadcrumb__links">
                            <a href="./index.html">Home</a>
                            <span>About Us</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb End -->

    <!-- About Section Begin -->
    <section class="about spad">
        <div class="container">
            <div class="about__content">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="section-title">
                            <h5>Our Specialization</h5>
                            <h2>Welcome Sea Side South Park</h2>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="about__text">
                            <p>The story of Sea Side South Park Hotel Colombo which opened its doors in 2010 is a splendid tale of continual improvement of product and the highest standards of quality in hospitality.
Having embraced over 3 decades of expertise in hospitality our vision and beliefs are firmly grounded in extending a true personalized service to all our guests, laced with an unforgettable luxury hotel experience.
The brand has enticed many elite personalities from around the world including heads of government, prime ministers of leading nations, royalty, well known sports and entertainment personalities and many more.</p>
                        </div>
                    </div>
                </div>
            </div>
           
        </div>
    </section>
    <!-- About Section End -->

    <!-- Chooseus Section Begin -->
    <div class="chooseus spad set-bg" data-setbg="img/chooseus-bg.jpg">
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-8 text-center">
                    <div class="chooseus__text">
                        <div class="section-title">
                            <h5>WHY CHOOSE US</h5>
                            <h2>Contact us now to get the latest deals and for the next booking</h2>
                        </div>
                        <a href="#" class="primary-btn">Booking Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Chooseus Section End -->

    <!-- History Section Begin -->
    <section class="history spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title history-title">
                        <h5>Our History</h5>
                        <h2>Explore Our Hotel</h2>
                    </div>
                </div>
            </div>
            <div class="history__content">
                <div class="row">
                    <div class="col-lg-5 col-md-5">
                        <div class="history__item left__item">
                            <div class="history__date"></div>
                            <span>Colombo</span>
                            <h4>Sea Side South Park/h4>
                            <img src="img/m2" alt="">
                            <p>Having embraced over 3 decades of expertise in hospitality our vision and beliefs are firmly grounded in extending a true personalized service to all our guests, laced with an unforgettable luxury hotel experience.</p>
                        </div>
                        <div class="history__item left__item mb-0">
                            <div class="history__date"></div>
                            <span>Galle</span>
                            <h4>Sea Side Beach Hotel</h4>
                            <img src="img/m3.jpg" alt="">
                            <p>Sri Lanka’s iconic landmark, The Sea Side Beach Hotel, is situated in the heart of Galle, along the seafront and facing the famous Galle Face Green.</p>
                        </div>
                    </div>
                    <div class="col-lg-5 offset-lg-2 col-md-5 offset-md-2">
                        <div class="history__item right__first__item">
                            <div class="history__date"></div>
                            <span>Bentota</span>
                            <h4>Sea Beach Hotel</h4>
                            <img src="img/m4.jpg" alt="">
                            <p>Located in Bentota, Sea Beach Hotel offers beachfront accommodation 150 m from Bentota Central Beach and provides various facilities, such as a restaurant, a fitness centre and a bar. An indoor swimming pool and a bicycle rental service are available for guests.</p>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- History Section End -->

    <!-- Footer Section Begin -->
        <footer class="footer set-bg" data-setbg="img/footer-bg.jpg">
        
        <div class="container">
            <div class="footer__content">
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="footer__about">
                            <div class="footer__logo">
                                <a href="#"><img src="img/logo.png" alt=""></a>
                            </div>
                            <h4>0112555555</h4>
                            <ul>
                                <li>96, Sea Side South Park, Colombo</li>
                                <li>Info.seasidesouth@gmail.com</li>
                            </ul>
                            <div class="footer__social">
                                <a href="https://www.facebook.com/seasidehotelandspa/"><i class="fa fa-facebook"></i></a>
                                <a href="https://twitter.com/seasidehs"><i class="fa fa-twitter"></i></a>
                                <a href="https://in.linkedin.com/company/seasideofficiel"><i class="fa fa-linkedin"></i></a>
                                <a href="https://www.youtube.com/watch?v=SCM4o_lnZf4"><i class="fa fa-youtube-play"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 offset-lg-1 col-md-5 offset-md-1 col-sm-6">
                        <div class="footer__widget">
                            <h4>Multiple Hotels</h4>
                            <ul>
                                <li><a href="#">Sea Side South Park</a></li>
                                <li><a href="#">Sea Side South Beach</a></li>
                                <li><a href="#">Sea Beach Hotel</a></li>
                               
                            </ul>
                          
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-8 col-sm-12">
                        <div class="footer__newslatter">
                            <h4>Subscribe our newlatester</h4>
                            <form action="#">
                                <input type="text" placeholder="Your E-mail Address">
                                <button type="submit">Subscribe</button>
                            </form>
                            
                        </div>
                    </div>
                </div>
            </div>
          
        </div>
    </footer>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
</body>

</html>