$(document).ready(function(){
            $("#btn").click(function(){
            $("#div1").load("filtered.php"); //this goes to #div1 div
			alert('Checking Rooms...');
			return false;
            });
			
			event.preventDefault();
          });
